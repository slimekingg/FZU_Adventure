"use strict";
cc._RF.push(module, 'db878SmwJ9C2JaR4B2HFDOp', 'game');
// script/game.js

"use strict";

cc.Class({
  "extends": cc.Component,
  properties: {},
  onload: function onload() {
    cc.director.getCollisionManager().enabled = true;
    cc.director.getPhysicsManager().enabled = true; //cc.director.getPhysics3DManager().enabled = true;

    cc.director.getPhysicsManager().gravity = cc.v2(0, -640);
  }
});

cc._RF.pop();