
cc.Class({
    extends: cc.Component,

    properties: {

    },

    onload(){
        cc.director.getCollisionManager().enabled = true;
        cc.director.getPhysicsManager().enabled = true;
        //cc.director.getPhysics3DManager().enabled = true;
        cc.director.getPhysicsManager().gravity = cc.v2(0, -640);
    }

});
