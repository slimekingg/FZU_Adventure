
require('./assets/script/game');
